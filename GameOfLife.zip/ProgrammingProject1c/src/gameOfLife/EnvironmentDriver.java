package gameOfLife;

public class EnvironmentDriver {
	
	public static void main(String[] args){
		
		String filename = "GameOfLife4.txt";
		Environment e = new Environment(filename);
		//System.out.println("This cell has: " + e.getNeighbors(1, 2));
		
		boolean test = true;
		e.setCanvas();
		while(test){
			e.runSimulation();
		}
		
	}

}

